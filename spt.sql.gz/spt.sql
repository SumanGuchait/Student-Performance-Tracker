-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2021 at 08:03 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spt`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `admin_email` varchar(255) NOT NULL,
  `admin_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`admin_email`, `admin_password`) VALUES
('sandipan@gmail.com', '123456'),
('suman@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `stud_id` int(3) NOT NULL,
  `sub_id` varchar(255) NOT NULL,
  `month` varchar(9) NOT NULL,
  `total` int(3) NOT NULL,
  `attendance` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`stud_id`, `sub_id`, `month`, `total`, `attendance`) VALUES
(41, 'CS40', 'January', 25, 23),
(41, 'CS40', 'July', 54, 43),
(41, 'CS43', 'January', 23, 13),
(41, 'CS43', 'July', 54, 43),
(41, 'CS45', 'January', 14, 3),
(41, 'CS45', 'July', 23, 5);

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `email` varchar(255) NOT NULL,
  `subject` varchar(10) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `stud_id` int(3) NOT NULL,
  `sub_id` varchar(255) NOT NULL,
  `month` varchar(9) NOT NULL,
  `total` int(3) NOT NULL,
  `marks` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`stud_id`, `sub_id`, `month`, `total`, `marks`) VALUES
(41, 'CS40', 'January', 100, 98),
(41, 'CS40', 'July', 100, 56),
(41, 'CS43', 'January', 100, 78),
(41, 'CS43', 'July', 100, 87),
(41, 'CS45', 'January', 100, 65),
(41, 'CS45', 'July', 100, 67);

-- --------------------------------------------------------

--
-- Table structure for table `student_login`
--

CREATE TABLE `student_login` (
  `stud_id` int(11) NOT NULL,
  `stud_name` varchar(255) NOT NULL,
  `stud_year` int(1) NOT NULL,
  `stud_sem` int(1) NOT NULL,
  `stud_dept` varchar(20) NOT NULL,
  `stud_phno` bigint(10) NOT NULL,
  `stud_email` varchar(255) NOT NULL,
  `stud_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_login`
--

INSERT INTO `student_login` (`stud_id`, `stud_name`, `stud_year`, `stud_sem`, `stud_dept`, `stud_phno`, `stud_email`, `stud_password`) VALUES
(17, 'Anwesha', 4, 8, 'CSE', 9635841258, 'anwesha@gmail.com', '3695321'),
(47, 'samir', 4, 8, 'CSE', 9876543210, 'samir@gmail.com', '123456'),
(43, 'Sandipan', 4, 8, 'CSE', 9865321475, 'sandipan@gmail.com', '1234567'),
(41, 'suman', 4, 8, 'cse', 1234567890, 'suman@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_login`
--

CREATE TABLE `teacher_login` (
  `t_name` varchar(255) NOT NULL,
  `sub_id` varchar(10) NOT NULL,
  `sub_name` varchar(255) NOT NULL,
  `t_phno` bigint(10) NOT NULL,
  `t_email` varchar(255) NOT NULL,
  `t_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher_login`
--

INSERT INTO `teacher_login` (`t_name`, `sub_id`, `sub_name`, `t_phno`, `t_email`, `t_password`) VALUES
('BDu', 'CS40', 'SW', 9563287456, 'bdu@gmail.com', '256874'),
('DC', 'CS45', 'DBMS', 9564321785, 'dc@gmail.com', '123456789'),
('SDe', 'CS43', 'Design Lab', 9525648285, 'sde@gmail.com', '356284');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`admin_email`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`stud_id`,`sub_id`,`month`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`stud_id`,`sub_id`,`month`);

--
-- Indexes for table `student_login`
--
ALTER TABLE `student_login`
  ADD PRIMARY KEY (`stud_email`);

--
-- Indexes for table `teacher_login`
--
ALTER TABLE `teacher_login`
  ADD PRIMARY KEY (`t_email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
